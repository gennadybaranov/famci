﻿namespace SOLIDHomework.Core.Calculators
{
    public interface ICalculator
    {
        decimal CalculateTotal(ShoppingCart shoppingCart);
    }
}
