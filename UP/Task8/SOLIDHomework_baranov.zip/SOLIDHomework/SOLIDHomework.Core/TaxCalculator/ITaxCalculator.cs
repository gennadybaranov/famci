﻿namespace SOLIDHomework.Core.TaxCalculator
{
    public interface ITaxCalculator
    {
        decimal CalculateTax(decimal sum);
    }
}
