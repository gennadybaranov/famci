﻿namespace SOLIDHomework.Core.Model
{
    public enum PaymentMethod
    {
        CreditCard,
        Cash,
        OnlineOrder
    }
}