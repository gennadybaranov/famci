﻿namespace SOLIDHomework.Core.Model
{
    public class BasePaymentMethod
    {
        public bool IfNeedsChargeCard { get; set; }
        public bool IfNeedsNotification { get; set; }
    }
}
