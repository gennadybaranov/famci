﻿namespace SOLIDHomework.Core.Model
{
    public class CreditCard : BasePaymentMethod
    {
    }
}
