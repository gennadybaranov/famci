﻿namespace SOLIDHomework.Core.Model
{
    public class OnlineOrder : BasePaymentMethod
    {
    }
}
