﻿using System;

namespace SOLIDHomework.Core
{
    public class CreditCart
    {
        public string CardNumber { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string NameOnCard { get; set; }
    }
}