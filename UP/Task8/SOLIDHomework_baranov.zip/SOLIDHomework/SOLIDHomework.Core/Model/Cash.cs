﻿namespace SOLIDHomework.Core.Model
{
    public class Cash : BasePaymentMethod
    {
    }
}
