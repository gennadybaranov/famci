﻿using System;
using System.Configuration;
using SOLIDHomework.Core.Loggers;
using SOLIDHomework.Core.Model;
using SOLIDHomework.Core.Payment;
using SOLIDHomework.Core.Services;

namespace SOLIDHomework.Core
{
    //Order - check inventory, charge money for credit card and online payments, 
    //tips:
    //think about SRP, DI, OCP
    //maybe for each type of payment type make sense to have own Order-based class?
    public abstract class BaseOrderService
    {
        private readonly IInventoryService _inventoryService;
        private readonly IUserService _userService;

        protected BaseOrderService(IInventoryService inventoryService, IUserService userService)
        {
            if (inventoryService == null)
            {
                throw new ArgumentException("Inventory Service");
            }

            if (userService == null)
            {
                throw new ArgumentException("User Service");
            }

            _inventoryService = inventoryService;
            _userService = userService;
        }

        public abstract void Checkout(string username, ShoppingCart shoppingCart, PaymentDetails paymentDetails,
                                      bool notifyCustomer);

        public void NotifyCustomer(string username)
        {
            string customerEmail = _userService.GetByUsername(username).Email;
            if (!String.IsNullOrEmpty(customerEmail))
            {
                try
                {
                    //construct the email message and send it, implementation ignored
                }
                catch (Exception ex)
                {
                    //log the emailing error, implementation ignored
                }
            }
        }

        public void ReserveInventory(ShoppingCart cart)
        {
            foreach (OrderItem item in cart.OrderItems)
            {
                try
                {
                    _inventoryService.Reserve(item.Code, item.Amount);
                }
                catch (InsufficientInventoryException ex)
                {
                    throw new OrderException("Insufficient inventory for item " + item.Code, ex);
                }
                catch (Exception ex)
                {
                    throw new OrderException("Problem reserving inventory", ex);
                }
            }
        }

        public void ChargeCard(PaymentDetails paymentDetails, ShoppingCart cart)
        {
            PaymentServiceType paymentServiceType;
            Enum.TryParse(ConfigurationManager.AppSettings["paymentType"], out paymentServiceType);
            try
            {
                IPayment payment = PaymentFactory.GetPaymentService(paymentServiceType);
                string serviceResponse;
                bool result = payment.Charge(cart.TotalAmount(), new CreditCart()
                {
                    CardNumber = paymentDetails.CreditCardNumber,
                    ExpiryDate = paymentDetails.ExpiryDate,
                    NameOnCard = paymentDetails.CardholderName
                }, out serviceResponse);

                if (!result)
                {
                    throw new Exception(String.Format("Error on charge : {0}", serviceResponse));
                }
            }
            catch (AccountBalanceMismatchException ex)
            {
                throw new OrderException("The card gateway rejected the card based on the address provided.", ex);
            }
            catch (Exception ex)
            {
                throw new OrderException("There was a problem with your card.", ex);
            }

        }
    }

    public class CardOrderService : BaseOrderService
    {
        public CardOrderService(IInventoryService inventoryService, IUserService userService) :base(inventoryService, userService)
        {
        }

        public override void Checkout(string username, ShoppingCart shoppingCart, PaymentDetails paymentDetails, bool notifyCustomer)
        {
            ChargeCard(paymentDetails, shoppingCart);
            ReserveInventory(shoppingCart);
            LoggerContext.Current.Write("Success checkout");
        }
    }

    public class OnlineOrderService : BaseOrderService
    {
        public OnlineOrderService(IInventoryService inventoryService, IUserService userService)
            : base(inventoryService, userService)
        {
        }

        public override void Checkout(string username, ShoppingCart shoppingCart, PaymentDetails paymentDetails, bool notifyCustomer)
        {
            ChargeCard(paymentDetails, shoppingCart);
            ReserveInventory(shoppingCart);
            if (notifyCustomer)
            {
                NotifyCustomer(username);
            }
            LoggerContext.Current.Write("Success checkout");
        }
    }

    public class CashOrderService : BaseOrderService
    {
        public CashOrderService(IInventoryService inventoryService, IUserService userService)
            : base(inventoryService, userService)
        {
        }

        public override void Checkout(string username, ShoppingCart shoppingCart, PaymentDetails paymentDetails, bool notifyCustomer)
        {
            ReserveInventory(shoppingCart);
            LoggerContext.Current.Write("Success checkout");
        }
    }
    
    public class OrderException : Exception
    {
        public OrderException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
    public class AccountBalanceMismatchException : Exception
    {
    }
}
