﻿namespace SOLIDHomework.Core.Services
{
    public class InventoryService : IInventoryService
    {
        // that is Database-based service 
        public void Reserve(string identifier, int quantity)
        {
           
        }
    }
}