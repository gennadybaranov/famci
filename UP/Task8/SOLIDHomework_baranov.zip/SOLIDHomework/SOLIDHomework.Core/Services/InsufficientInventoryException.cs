﻿using System;

namespace SOLIDHomework.Core.Services
{
    public class InsufficientInventoryException : Exception
    {
    }
}