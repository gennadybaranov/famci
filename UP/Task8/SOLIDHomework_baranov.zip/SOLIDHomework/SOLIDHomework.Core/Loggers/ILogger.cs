﻿namespace SOLIDHomework.Core.Loggers
{
    public interface ILogger
    {
        void Write(string text);
    }
}
