﻿using System.Collections.Generic;
using SOLIDHomework.Core.Calculators;
using SOLIDHomework.Core.TaxCalculator;

namespace SOLIDHomework.Core
{
    //there are OCP and SOC violation
    //
    public class ShoppingCart
    {
        private readonly List<OrderItem> orderItems;
        private readonly ICalculator calculator;

        public ShoppingCart(ICalculator calculator)
        {
            this.orderItems = new List<OrderItem>();
            this.calculator = calculator;
            this.TaxCalculator = new DefaultTaxCalculator();
        }

        public IEnumerable<OrderItem> OrderItems
        {
            get { return orderItems; }
        }

        public ITaxCalculator TaxCalculator { get; set; }

        public void Add(OrderItem orderItem)
        {
            orderItems.Add(orderItem);
        }
        
        public decimal TotalAmount()
        {
            decimal total = calculator.CalculateTotal(this);
            total = TaxCalculator.CalculateTax(total);
            return total;
        }
    }
}
