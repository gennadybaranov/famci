﻿namespace SOLIDHomework.Core.Payment
{
    public enum PaymentServiceType
    {
        PayPal = 1
        , WorldPay = 2
    }
}