﻿using System;
using System.Configuration;

namespace SOLIDHomework.Core.Payment
{
    public class PaymentFactory
    {
        public static IPayment GetPaymentService(PaymentServiceType serviceType)
        {
            switch (serviceType)
            {
                case PaymentServiceType.PayPal:
                    string accountName = ConfigurationManager.AppSettings["accountName"];
                    string password = ConfigurationManager.AppSettings["password"];
                    return new PayPalPayment(accountName, password);

                case PaymentServiceType.WorldPay:
                    string bankID = ConfigurationManager.AppSettings["BankID"];
                    string domenId = ConfigurationManager.AppSettings["DomenID"];
                    return new WorldPayPayment(bankID, domenId);
                default:
                    throw new NotImplementedException("No such service.");
            }
        }
    }
}